package com.example.headsup;

public interface IFragmentListener {
    void onInputSent(String input);
}
